export { default } from "./startApplication";

export * from "./types";
