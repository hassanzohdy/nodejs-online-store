import { Request } from "core/http/types/request";
import { Response } from "core/http/response";

export default function ContactUsController(
  request: Request,
  response: Response
) {}
