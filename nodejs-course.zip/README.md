# Nodejs Online Store App

This repository is part of nodejs course for backend.

The application is built with `Typescript` `Express Js` `Nodemon` `MongoDB` and `Mongez`.

## Installation

Just clone the repository then:

`yarn install`

Or

`npm i`

## Starting the application

Open the application root directory then run:

`yarn start`

Or

`npm run start`

## Contribution

Feel free to make any **PR** or if you've any suggestions or issues open a new one :)
