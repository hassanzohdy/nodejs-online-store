import "app";

import startApplication from "core/application";

startApplication();
