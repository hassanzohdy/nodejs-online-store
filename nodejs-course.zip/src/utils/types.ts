export type DynamicObject = {
  [key: string]: any;
};
